#include <iostream>
#include <cstdlib>
using namespace std;

template <class T>
class datastore{
	struct item
	{
		T id;
		struct item* next;
		
	};

	struct count_list
	{
		int count; 
		int num; 
		count_list*next;
		struct item* node;
	};
	

	count_list* head;

	count_list* find(T);
	void delete_node(count_list*,T);
	count_list* max_node();
	count_list* get_count_list(int count);
	void insert_to_count(count_list *,T n);
	
	public:
		datastore();
		~datastore();
		void insert(T);
		void print();
		int search(T);
		int find_max();
		void list_max();
		void decrement(T);
		void reset();
		void list_zero();
		int eject(T);

};

template <class T>
int datastore<T>::eject(T a){
	if(head == NULL)
		return 0;
	count_list* curr = find(a);
	if(curr == NULL)
		return 0;
	else
		delete_node(curr, a);
	return 1;
}


template <class T>

void datastore<T>::list_zero(){
	if(head->count==0){
		struct item* it= head->node;
		while(it!=NULL){
			cout<<it->id<<" ";
			it=it->next;
		}
		cout<<endl;
	}
	
}
template <class T>

void datastore<T>::insert_to_count(count_list * curr, T val){
	item *new_item=new item;
	new_item->next = curr->node;
	new_item->id=val;
	curr->node=new_item;
	curr->num++;

} 

template <class T>

void datastore<T>::reset(){
	count_list* curr=head;
	count_list *zero; 
	if(head->count!=0){
		zero= new count_list;
		
		zero->next = head;
		zero->count=0;
		zero->node = NULL;
		head = zero;
		
	}
	zero=head;
	struct item* it;
	while(curr != NULL){
			it= curr->node;
			while(it!=NULL){
				


				item *new_item=new item;
				new_item->next = zero->node;
				new_item->id=it->id;
				zero->node=new_item;

				zero->num++;
				delete_node(curr,it->id);
				it=it->next;
	
			}
			curr=curr->next;
		}	
}


template <class T>


datastore<T>::datastore(){

	head=NULL;
}
template <class T>

datastore<T>::~datastore(){
	delete head;
}
template <class T>

void datastore<T>::delete_node(count_list* newlist, T a){
	//If only 1 item present
	if(newlist->node->next == NULL){
		if(newlist == head ){
			if(newlist -> next == NULL)
				head= NULL;
			else
				head=head->next;
		}
		else{
			count_list* curr= head;

			while(curr->next!=newlist){
				curr= curr->next;
			}
			curr->next=newlist->next;
			newlist=NULL;
		}	
	}
	//If multiple items are there in that node
	else{
		struct item* it= newlist->node;
		struct item* prev=NULL;
		//int c=0;
		//If first element is 'a'
		if(it->id == a){
			newlist->node= it ->next;
			it=NULL;
		}
		else{
			while(it->next !=NULL){
				//cout<<it->id<< " n item if "<<a<<endl;
				if(it->id == a){
					//cout<<"break";
					break;
				}
				prev=it;
				it=it->next;
				//if(c==2)
				//	break;
			}
			
			prev->next=it->next;
			it=NULL;
		}
			
	}
	
}

template <class T>

typename datastore<T>::count_list* datastore<T>::find(T a){
	count_list* curr=head;
	while(curr != NULL){
	struct item* it= curr->node;
		while(it!=NULL){
			if(it->id == a)
				return curr;
			it=it->next;
		}
		curr=curr->next;
	}
	return NULL;
}

template <class T>
int datastore<T>::search(T n){

	count_list *curr=find(n);
	if(curr==NULL){
		return -1;
	}
	else return curr->count;
}


template <class T>
typename datastore<T>::count_list* datastore<T>:: max_node(){
	count_list *curr = head;
	if(head==NULL){
		return NULL;
	}
	while(curr->next!=NULL){
		curr=curr->next;
	}
	return curr;
}

template <class T>
int datastore<T>:: find_max(){
	count_list * max = max_node();
	if(max==NULL){
		return 0;
	}
	else 
		return max->count;
}

template <class T>
void datastore<T>::list_max(){
	count_list *max = max_node();
	struct item* it= max->node;
		while(it!=NULL){
			cout<<it->id<<" ";
			it=it->next;
		}
	cout<<endl;
	
}

template <class T>
typename datastore<T>::count_list* datastore<T>::get_count_list(int n){
	count_list *curr= head;
	if(curr->count>n ||curr ==NULL){
		count_list* newlist1 = new count_list;
		newlist1->next=curr;
		newlist1->count = n;
		newlist1->node = NULL;
		head = newlist1;
		return head;
	}
	count_list *prev = curr;
	while(curr->count < n || curr->next!=NULL){
		prev = curr;
		curr=curr->next;
	}
	if(curr->count==n){
		return curr;
	}
	else {
		count_list* newlist1 = new count_list;
		newlist1->next=curr;
		prev->next=newlist1;
		newlist1->num=1;
		newlist1->count=n;
		newlist1->node = NULL;		
		return newlist1;
	}
	
}

template <class T>
void datastore<T>::decrement(T n){
	
	count_list * curr = find(n);
	if(curr==NULL)
		return;
	//cout<<"found "<<n<<" at count "<<curr->count<<endl;
	
	int new_count= curr->count -1;
	
	delete_node(curr,n);
	if(new_count == -1)
		return;

	count_list *newcount = get_count_list(new_count);
	//cout<<"got count "<<newcount->count<<endl;
	item *new_item=new item;
	new_item->next = newcount->node;
	new_item->id=n;
	newcount->node=new_item;
	newcount->num++;
	//print();

}


template <class T>
void datastore<T>::insert(T a){
	item* new_item;
		
		//First element of list of list
		if(head==NULL){
			head=new count_list;
			head->num=1;
			head->count=1;
			head->next=NULL;
			head->node =new item;
			head->node->next=NULL;
			//cout<<"First element is "<<a<<endl;
			head->node->id=a;
		}
		else{
			count_list* newlist = find(a);
			//If the item to be inserted is not already present, insert to the head itself. 
			if(!newlist){
				
				if(head->count==0){
					newlist = new count_list;
					newlist->next = head->next;
					head->next = newlist;
					newlist->count=1;
					newlist->node = new item;
					newlist->node->id = a;
					newlist->node->next = NULL;
				}
				else if(head->count==1){
					insert_to_count(head,a);
				}
				else{
					newlist = new count_list;
					newlist->count =1;
					newlist->next = head;
					head = newlist;
					newlist->node = NULL;
					insert_to_count(newlist,a);
				}
			}
			else{
				


				//If the list of count corresponding to that element doesnt exist
				if(newlist -> next == NULL){
					//cout<<a<<" List doesnt exist\n";
					count_list* newlist1 = new count_list;
					newlist -> next = newlist1;
					newlist1->num=1;
					newlist1->count=newlist->count + 1;
					newlist1->next=NULL;
					newlist1->node =new item;
					newlist1->node->next=NULL;
					newlist1->node->id=a;
				}
				//If he list of count corresponding to that element exist and 
				//it is the next to the current count_list
				else if( newlist -> next != NULL && newlist->count == newlist->next->count -1){
						//cout<<a<<" List  exist\n";
						count_list* newlist1 = newlist->next;
						new_item=new item;
						new_item->next = newlist1->node;
						new_item->id=a;
						newlist1->node=new_item;
						newlist1->num++;
				}
				//If there next count_list's count is not next count,  eg. 2 -- 4, not 2 -- 3
				else{
					//cout<<a<<" List doesnt exist but shud be inserted\n";
					count_list* newlist1 = new count_list;
					newlist1->next=newlist->next;
					newlist->next=newlist1;
					newlist1->num=1;
					newlist1->count=newlist->count + 1;
					newlist1->node =new item;
					newlist1->node->next=NULL;
					newlist1->node->id=a;
				}
				//Delete that node from the current list
				delete_node(newlist,a);
			}
		
	}
}

template <class T>
void datastore<T>::print(){

	count_list* curr=head;
	while(curr != NULL){
		cout<<curr->count<<" ";
		struct item* it= curr->node;
		while(it!=NULL){
			cout<<it->id<<" ";
			it=it->next;
		}
		cout<<endl;
		curr=curr->next;
	}
}
