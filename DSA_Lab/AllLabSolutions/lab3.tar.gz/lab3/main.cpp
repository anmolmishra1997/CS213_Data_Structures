#include "list_of_lists_sol.h"

int main(){

	datastore<float> x;
	int n;
	float a;
	char ch;
	cin>>ch;
	while(ch!='a'){

		switch(ch){
			cout<<"ch"<<ch;
			case 'i':
				{
					cin>>n;
					
					for(int i=0;i<n;i++){
						
						cin>>a;
						x.insert(a);
					}
					break;
				}
			case 'p':
				{
					x.print();
					break;
				}

			
			case 's':
				{
					
					cin>>a;
					cout<<x.search(a)<<endl;
					break;
				}
			case 'm':
				{
					cout<<x.find_max()<<endl;
					break;
				}
			case 'l':
				{
					x.list_max();
					break;				
				}
			case 'd':
				{
					cin>>a;
					x.decrement(a);
					break;
				}
			case 'r':
				{
					x.reset();
					break;
				}
			case 'z':
				{
					x.list_zero();
					break;
				}
			case 'e':
				{
					cin>>a;
					cout<<x.eject(a)<<endl;
					break;
				}
			case 'a':
				exit(0);
			default:
					cout<<"Invalid input provided!\n";
					exit(0);
		}
		cin>>ch;
	}

	return 0;
}
