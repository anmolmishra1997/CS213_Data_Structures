#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

typedef long long LL;
typedef pair<int,LL> plli;

// comparator for priority queue of pairs of (machine id,weight)
class mycomparison
{
public:
  bool operator() (const plli & lhs, const plli &rhs) const
  {
  	return (lhs.second != rhs.second) ? (lhs.second > rhs.second  ) : (lhs.first > rhs.first);
  }
};

int main()
{
	int t;
	LL l,n,m,w;
	cin >> t;
	priority_queue<plli,vector<plli>,mycomparison> Q;
	priority_queue<LL,vector<LL>, greater<LL> > dryerQ;
	plli top;
	for (int i = 0; i < t; ++i)
	{

		cin >> l >> n >> m >> w;
		vector<LL> w_i(n);
		for(int j=0; j < n; j++)
		{
			cin >> w_i[j];
			Q.push(make_pair(j,w_i[j]));
		}

		// Each of the L loads should be greedily washed such that it finishes as soon as possible
		vector<LL> times(l);
		for(int j = 0; j < l; j++)
		{
			top = Q.top();
			Q.pop();
			times[j] = top.second;
			Q.push(make_pair(top.first,w_i[top.first] + times[j]));

		}
		while(!Q.empty())
			Q.pop();

		LL ans;
		if(m >= l){
			ans = w + times[l-1];
		}
		else
		{
			// These loads should then be greedily dried in the same order,
			// each time similarly using the dryer that will finish as early
			//  as possible.
			priority_queue<LL,vector<LL>, greater<LL> > dryerQ;
			for(int j = 0; j < m; j++)
			{
				dryerQ.push(0);
			}
			for(int j = 0 ; j < l; j++)
			{
				ans = max(times[j],dryerQ.top()) + w;
				dryerQ.pop();
				dryerQ.push(ans);
			}
		}

		cout << ans << endl;

	}
}
