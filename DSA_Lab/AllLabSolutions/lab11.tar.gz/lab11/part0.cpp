// constructing priority queues
#include <iostream>       // std::cout
#include <queue>          // std::priority_queue
#include <vector>         // std::vector
#include <functional>     // std::greater
using namespace std;

class mycomparison
{
    bool reverse;
    public:
    mycomparison(const bool& revparam=false)
    {reverse=revparam;}
    bool operator() (const int& lhs, const int&rhs) const
    {
        if (reverse) return (lhs>rhs);
        else return (lhs<rhs);
    }
};

int main ()
{
    typedef priority_queue<int, vector<int>, mycomparison> mypq_type;
    mypq_type pq1(mycomparison(true));
    int n,val,get_min_times;
    cin>>n;
    for (int i=0;i<n;i++){
        cin>>val;
        pq1.push(val);
    }
    cin>>get_min_times;
    while (get_min_times--)
    {
        val=pq1.top();
        std::cout <<val <<endl;
        pq1.pop();
        pq1.push(val*2);
    }
    return 0;
}
