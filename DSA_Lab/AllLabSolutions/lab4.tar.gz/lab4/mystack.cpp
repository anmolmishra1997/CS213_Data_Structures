#include "mystack.h"

Stack::~Stack()
{
	node* temp = head;
	while(temp != NULL )
	{
		head = head->next;
		delete temp;
		temp = head;
	}
}

int & Stack::top() const
{
	int & ret = head->data;
	return ret;
}

int Stack::pop()
{
   int value;
	
	if(empty())
		return -1;

	node *temp = head;
	head = head->next;

	value= temp->data;
	delete temp;

	size -= 1;
	return value;
}

void Stack::push(int x)
{
	node *curr = new node;
	curr->data = x;
	curr->next = head;
	head = curr;
	size += 1;
	return;
}

bool Stack::empty() const
{
	return (size == 0);
}

/*int main ()
{
  Stack mystack;

  mystack.push(10);
  mystack.push(20);

  mystack.top() -= 5;

  std::cout << "mystack.top() is now " << mystack.top() << '\n';

  mystack.pop();
  std::cout << "mystack.top() is now " << mystack.top() << '\n';

  return 0;
}*/
