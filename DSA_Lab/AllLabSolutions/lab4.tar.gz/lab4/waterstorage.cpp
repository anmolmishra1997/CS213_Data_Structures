#include "mystack.h"
#include <vector>
using namespace std;

void getNextGreater(vector<int> &h, vector<int> &arr){ 
	/*
		given vector of heights 'h', prepares vector arr so that
		arr[i] = smallest j>i such that h[j]>=h[i] and arr[i]=-1
		if such a j does not exist. 
	*/
	int n=h.size();
	arr.resize(n);
	Stack S;
	for(int i=0;i<n;i++){
		if(S.empty()){
			S.push(i);
		}
		else{
			while(!S.empty()){
				if(h[S.top()]<=h[i]){
					arr[S.top()]=i;
					S.pop();
				}
				else{
					break;
				}
			}
			S.push(i);
		}
	}
	while(!S.empty()){
		arr[S.top()]=-1;
		S.pop();
	}
	return ;
}

int getWaterAmount(vector<int> &h){
	/*
		given vector of heights output amount of water it can hold
		as defined in the problem statement
	*/
	int n=h.size();
	vector<int> tmp(n); //tmp[i] = max element in h[i...(n-1)]
	int Max=-100000000;
	for(int i=n-1;i>=0;i--){
		tmp[i]=max(Max,h[i]);
                Max=tmp[i];
	}
	vector<int> arr(n);
	getNextGreater(h,arr);

	int ans=0;
	int i=0;
	while(i<n){
		if(arr[i]==-1){
			while(i<n){
				ans+=tmp[i]-h[i];
				i++;
			}
		}
		else{
			int j=i;
			while(j<arr[i]){
				ans+=h[i]-h[j];
				j++;
			}
			i=arr[i];
		}
	}
	return ans;
}

int main(){
	int n;
	cin>>n; //take array size as input
	vector<int> h(n);
	for(int i=0;i<n;i++){
		cin>>h[i];
	}
	vector<int> arr(n);
	getNextGreater(h,arr);
	for(int i=0;i<n;i++)
		   cout<<h[i]<<" ";
    cout << endl;

/*
	for(int i=0;i<n;i++){
		if(arr[i] == -1) 
		   cout<<arr[i]<<" ";
		else
  		   cout<<h[arr[i]]<<" ";
    }
	cout<<endl;
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout<<endl;
*/
	cout<<getWaterAmount(h)<<endl;
	return 0;
}
