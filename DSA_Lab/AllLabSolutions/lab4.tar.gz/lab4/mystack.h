#include <iostream>

class Stack{

	// Internal struct which stores node related information.
    struct node
    {
        int data;           // value in node is of type int
        node * next;
    };
	node* head;
	size_t size;

public:
	Stack() : head(NULL),size(0) {}
	~Stack();
	int & top() const;
	int pop();
	void push(int);
	bool empty() const;

};
